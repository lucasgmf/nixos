require('lualine').setup()

